from pathlib import Path



# file_name = Path('./lesson_6/test.txt')




# with open(file_name, 'r', encoding='utf-8') as file:
#     print(file.read())

# print('Hello world')


file_name = Path('./lesson_6/')
print(file_name)

with open(file_name / 'test.txt', 'r',) as file:
    print(file.read())
for elem in file_name.glob('*.txt'):
    # print(elem)
    ...